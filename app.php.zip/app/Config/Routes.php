<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');

//home
$routes->get('home','Home::index');
$routes->get('specialities','Specialities::index');
$routes->get('aboutus','Aboutus::index');


$routes->get('bookappointments','Bookappointments::index');
$routes->get('bookappointments','Bookappointments::index1');
$routes->post('/bookappointments/store', 'Bookappointments::store');
$routes->get('bookappointments/block/(:num)','Bookappointments::block/$1');


//$routes->get('registration','Registration::index');
//$routes->get('registration','Registration::create');
$routes->post('registration/store', 'Registration::store');
$routes->get('registration/index1/(:num)','Registration::index1/$1');
//$routes->get('registration/store', 'Registration::store');


$routes->get('contactus','Contactus::index');
$routes->post('contactus/store', 'Contactus::store');



//$routes->get('viewreg','Registration::index1');
$routes->get('viewreg/index1/(:num)','Registration::index1/$1');


$routes->get('viewreg','Viewreg::index');
$routes->get('viewreg/index1/(:num)','Viewreg::index1/$1');
$routes->get('registration','Viewreg::create');

$routes->get('vbookappointments', 'VBookappointments::index');
$routes->get('vbookappointments', 'VBookappointments::create');


$routes->get('loggin', 'User::index');
$routes->post('User/login_action', 'User::login_action');
$routes->get('User/hoome', 'User::hoome');
$routes->get('User/vbookappointments', 'User::vbookappointments');
$routes->get('User/vbookappointments/(:num)', 'User::vbookappointments/$1');
$routes->get('User/viewreg', 'User::viewreg');
$routes->get('User/viewreg1/(:num)', 'User::viewreg1/$1');
$routes->get('User/delete/(:num)', 'User::delete/$1');


$routes->get('reg', 'Usee::index');
$routes->get('User/reg', 'Usee::index');
$routes->post('Usee/reg', 'Usee::reg');
$routes->get('User/logout', 'User::logout');

$routes->get('User/code', 'User::code');




$routes->get('register', 'Registers::index');
$routes->post('register/store', 'Registers::store');


$routes->get('map_view', 'Map::map');

$routes->get('my_view','Book::index');

$routes->get('vbook', 'BookingController::index');
$routes->get('book', 'BookingController::index1');

$routes->post('book/submitBooking', 'BookingController::submitBooking');
$routes->post('bookappointments/submitBooking', 'Bookappointments::submitBooking');
$routes->group('date-time', function($routes) {
    $routes->post('generate-time-slots', 'App\Controllers\DateTimeSlotController::generateTimeSlots');
});


$routes->get('bookreg','Bookregistration::index');
$routes->post('bookreg/store', 'Bookregistration::store');

$routes->get('vbookreg','Bookregistration::index1');
$routes->get('vbookreg/index2/(:num)', 'Bookregistration::index2/$1');
$routes->get('vbookreg/(:num)', 'Bookregistration::index2/$1');

//$routes->get('registration/store', 'Registration::store');

$routes->get('laboratory', 'Services::index');
$routes->get('xray', 'Services::index1');
$routes->get('master', 'Services::index2');
$routes->get('physio', 'Services::index3');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
