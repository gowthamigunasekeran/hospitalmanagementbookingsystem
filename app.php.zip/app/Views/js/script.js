function toggle(){
            var x = document.getElementById("divv");

            if (x.style.display === "none") {
                x.style.display = "block";
            }
            else{
                x.style.display = "block";
            }
        }

$(document).ready(function(){
    var dtToday = new Date();
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if( month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = 'o' + day.toString();
    var maxDate = year + '-' + month + '-' + day;
    $('#datecontrol').attr('min', maxDate);
});

/*---datepicker---*/

$(function(){
    var arrayofDates = ["07-04-2023","08-04-2023","09-04-2023"];
    $("#datepicker1").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
       }
    });
});
    

$(function(){
    var arrayofDates = ["27-03-2023","28-03-2023", "29-03-2023"];
    $("#datepicker2").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker3").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker4").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker5").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker6").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker7").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker8").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker9").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-02-2023","06-03-2023"];
    $("#datepicker10").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["25-03-2023","06-03-2023"];
    $("#datepicker11").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});

$(function(){
    var arrayofDates = ["26-03-2023","28-03-2023"];
    $("#datepicker12").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
        }
    });
});


$(function(){
    var arrayofDates = ["07-03-2023","08-03-2023","09-03-2023"];
    $("#datepicker13").datepicker(
        {
            dateFormat:'dd-mm-yy',
            minDate: new Date(),
            beforeShowDay: function (date) {

            var string = jQuery.datepicker.formatDate("dd-mm-yy", date);
            return [arrayofDates.indexOf(string) == -1];
       }
    });
});