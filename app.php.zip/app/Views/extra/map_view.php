<!DOCTYPE html>
<html>
<head>
    <title>Map Example</title>
    <link rel="stylesheet" href="<?php echo base_url('leaflet/leaflet.css'); ?>">
    <script src="<?php echo base_url('leaflet/leaflet.js'); ?>"></script>
    <style>
        body{
            margin: 0;
            padding: 0;
            background: #262626;
        }
        .rating{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%) rotateY(180deg);
        display: flex;
    }

    .rating input{
        display: none;
    }

   .rating label{
    display: block;
    cursor: pointer;
    width: 50px;
   }

   .rating label:before{
    content: '\f005';
    font-family: fontAwesome;
    position: relative;
    display: block;
    font-size: 50px;
    color: #101010;
   }

   .rating label:after{
    content: '\f005';
    font-family: fontAwesome;
    position: absolute;
    display: block;
    font-size: 50px;
    color: #1f9cff;
    top: 0;
    opacity: 0;
    transition: .5s;
    text-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
   }
   .rating label:hover:after{
    opacity: 1;
   }
   .rating label:hover ~ label:after{
    opacity: 1;
   }
   .rating input:checked ~ label:after{
    opacity: 1;
   }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/fontawesome.min.css" integrity="sha512-cHxvm20nkjOUySu7jdwiUxgGy11vuVPE9YeK89geLMLMMEOcKFyS2i+8wo0FOwyQO/bL8Bvq1KMsqK4bbOsPnA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">
</head>
<body>
    <div class="rating">
        <input type="radio"  name="star" id="star1"><label for="star1"></label>
        <input type="radio"  name="star" id="star2"><label for="star2"></label>
        <input type="radio"  name="star" id="star3"><label for="star3"></label>
        <input type="radio"  name="star" id="star4"><label for="star4"></label>
        <input type="radio"  name="star" id="star5"><label for="star5"></label>
    </div>
    
</body>
</html>
