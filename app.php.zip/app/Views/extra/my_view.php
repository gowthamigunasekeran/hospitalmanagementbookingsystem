<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
	<?php include 'css/style5.css'; ?>

    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">
</head>
<body><br><br><br><br><br><br>
    <div class="container my-5">
        <base href="<?= site_url("/"); ?>"> 
        <?php $validation =  \Config\Services::validation(); ?> <hr> <br> <br>
        <div class="row" id="gc">
            <h1>GENERAL PHYSICIAN</h1> 
        </div>
        <br>
        <br>
        <div class="row">
            <div class="col-md-3">
                <div class="card-sl">
                    <div class="card-image2">
                        <img src="img/16.jpg">
                    </div>
                    <a class="card-action2"><i class="fa fa-heart"></i></a>
                        <form action=" " method ="post">
                        <div  class="card-heading">
                            <label>DR JACK</label>
                            <h6> (General physician)</h6>
                            <div hidden>
                                <input type="text" value="DR Jack (General physician)"> 
                            </div>
                        </div>
                        <div class="card-text2">
                            <form method="post" action="<?= base_url('public/book/submitBooking') ?>">
                            <label for="date">Select a date:</label>
                            <input type="date" name="date" id="date">
                            <br>
                            <br>

                            <label for="time_slot">Select a time slot:</label>
                            <select name="time_slot" id="text">
                                <option value="time_slot_1">9:00 am - 10:00 am</option>
                                <option value="time_slot_2">10:00 am - 11:00 am</option>
                                <option value="time_slot_3">11:00 am - 12:00 pm</option>
                                <option value="time_slot_4">12:00 pm - 1:00 pm</option>
                            </select>
                        </div>
                        <div class="card-text2" style="font-weight: bolder; color: black;">
                            FEE : RS.300/-
                        </div>
                        <button  type ="submit" class="card-button2"> Book now</button>
                    </form>
                    </form>
                </div>
            </div>
        </div>
    </div>
<script>
    // Show/hide time slots based on selected date
    $('#date').change(function() {
        var date = $(this).val();

        // Make an AJAX request to retrieve the available time slots for the selected date
        $.ajax({
            url: '<?= base_url('booking/getAvailableTimeSlots') ?>',
            type: 'post',
            data: { date: date },
            success: function(response) {
                // Hide all time slots
                $('#time_slot option').hide();

                // Show only the available time slots
                $.each(response, function(index, timeSlot) {
                    $('#time_slot option[value="' + timeSlot + '"]').show();
                });
            }
        });
    });
</script>
</body>
</html>
