<?php
 if (isset($_POST['checking_viewbtn'])) {
 	
 	$s_id = $_POST['student_id'];
 	echo $return = $s_id;
 }

?>

<?php 

$conn = mysql_connect("localhost","root","","hospital")

$d_id = $_GET['d_id'];
$result = mysqli_query($conn, "SELECT * FROM  hospitalregiss WHERE d_id = $d_id");

$d_id = mysqli_fetch_object($result);
echo json_encode($d_id);
?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
    <script type="text/javascript">
    	
    	$(document).ready(function(){

    		$('.viewbtn').click(function (e) {
    			e.preventDefault();

    			var stud_id = $(this).closest('tr').find('.stud_id').text();
    			//console.log(stud_id);
    			//alert("hello");

    			$.ajax({
    				type: "POST",
    				url: "code",
    				data:{
    					'checking_viewbtn': true,
    					'student_name': stud_id,
    				},
    				success: function (response){
    					console.log(response);
    				}
    			});

    		});
    	});
    </script>