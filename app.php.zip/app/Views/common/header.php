<html>
<head>
  <title> hospital </title>
  <style type="text/css">
    @import 'https://fonts.googleapis.com/css?family=Montserrat:300, 400, 700&display=swap';
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}
html {
    
    font-family: 'Montserrat', sans-serif;
    scroll-behavior: smooth;
}
a {
    text-decoration: none;
}

.navbar-nav a{
    font-size: 17px;
    font-weight: bolder;
    color: #8C001E;
    text-decoration: none;
    color: #0A7DAF;
    display: block;
    transition: all 0.3s ease;
}
.navbar-light .navbar-brand{
  color: black;
  font-size: 25px;
  text-transform: uppercase;
  font-weight: 700;
  letter-spacing: 2px;
}
.navbar-light .navbar-brand:focus,
.navbar-light .navbar-brand:hover{
  color: rgb(0, 0, 0,);
}
.navbar-light .navbar-nav .navbar-link{
  color: rgb(0, 0, 0);
}
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #13397C;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 14px;
  padding: 10px;
  width: 300px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}

.dropbtn {
  background-color:transparent;
  color: #0A7DAF;
  padding: 8px;
  font-size: 17px;
  border: none;
  cursor: pointer;
  font-weight: bolder;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  right: 0;
  background-color: #f9f9f9;
  min-width: 250px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 15px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: transparent;
}
</style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">  
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="CSS/swiper-bundle.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">

</head>
<body onload="slider()">
  <base href="<?= site_url("/"); ?>">
  <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
      <a class="navbar-brand " href="#"><img src="img/logooo.jpg" style="width: 40px;"><span style="color:#0A7DAF">BEST</span>HOSPITAL</a>
      <button style="color: black;" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsupportedcontent" aria-controls="navbarsupportedcontent" aria-expamded="false" aia-label="toggle navigation">
      <span class="navbar-toggler-icon"></span>
        </button>
      <a href="tel:+91 99339-94455" class=" button btn btn-danger" ><i class="fa fa-ambulance"></i><span> 24x7 EMERGENCY <br> +91 99339-94455</span></a>     
      <div class="collapse navbar-collapse" id="navbarsupportedcontent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link" href="home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="aboutus">About us</a></li>
          <li class="nav-item"><a class="nav-link" href="specialities">Specialities</a></li>
          <div class="dropdown" style="float:left;">
            <button class="dropbtn">Services</button>
              <div class="dropdown-content" style="left:0;">
                <a href="master"><i class="bi bi-arrow-right"></i>Master health check</a>
                <a href="laboratory"><i class="bi bi-arrow-right"></i>Laboratory Services</a>
                <a href="physio"><i class="bi bi-arrow-right"></i>Physiotherapy</a>
                <a href="xray"><i class="bi bi-arrow-right"></i>X-ray Radiology</a>
            </div>
          </div>
          <li class="nav-item"><a class="nav-link" href="contactus">Contact us</a></li>
        </ul>
      </div>
    </div>
    <div>
      <a class="button" href="bookappointments"><span>BOOK APPOINTMENTS</span></a>
    </div>
  </nav>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>
</html>
