<!DOCTYPE html>
<html>
    <head>
        <title>FOOTER DESIGN</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>
    <body>
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col mx-5">
                        <h3>ABOUT US</h3>
                        <p style="text-align:left; font-size:16px">To deliver quality healthcare at affordable prices and to strive with unrelenting commitment towards clinical excellence.</p>
                    </div>
                    <div class="col mx-2">
                        <h3>QUICK LINKS</h3>
                        <ul>
                            <li><a href="home">Home</a></li>
                            <li><a href="aboutus">About Us</a></li>
                            <li><a href="specialities">Specialities</a></li>
                            <li><a href="contactus">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col mx-2">
                        <h3>SPECIALITIES</h4>
                        <ul>
                            <li><a href="specialities/#ent">Ent</a></li>
                            <li><a href="specialities/#cardio">Cardiolody</a></li>
                            <li><a href="specialities/#dent">Dentistry</a></li>
                            <li><a href="specialities/#eye">Eye Specialists</a></li>
                            <li><a href="specialities/#gyno">Gynecologist</a></li>
                        </ul>
                    </div>
                    <div class="col mx-2">
                        <h3>OUR SERVICE</h3>
                        <ul>
                            <li><a href="master">Master Health Check</a></li>
                            <li><a href="laboratory">Laboratory Services</a></li>
                            <li><a href="physio">Physiotherapy</a></li>
                            <li><a href="xray">X-ray Radiology</a></li>
                        </ul>
                    </div>
                    <div class="col mx-5">
                        <h3>Follow us</h3>
                        <div calss="social-links">
                            <a href="#"><i class="bi bi-facebook mx-2"></i></a>
                            <a href="#"><i class="bi bi-twitter mx-2"  style="color: cyan;"></i></a>
                            <a href="#"><i class="bi bi-whatsapp mx-2" style="color: lightgreen;"></i></a>                           
                        </div>
                    </div>
                </div>
            </div>
            <hr style="color:white">
            <div class="end-text">
                <p style="text-align:center">Copyrights @2023 All rights reserved</p>
            </div>
        </footer>
    </body>
</html>

<script>
        const submitButton = document.getElementById("submit");
        const input = document.getElementById("date");

        input.addEventListener("keyup", (e) => {
            const value = e.currentTarget.value;
            submitButton.disabled = false;
            if(value === ""){
                submitButton.disabled = true;
            }
        });
    </script>