<?php

namespace App\Controllers;

class Aboutus extends BaseController
{
    public function index()
    {
        //echo view('common/header');
        echo view('aboutus');
        //echo view('common/footer');
        
    }
}



